from app import db
from datetime import datetime

class Candidato(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    nome = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(100), nullable=False)
    telefone = db.Column(db.String(20))
    linkedin = db.Column(db.String(150))
    observacoes = db.Column(db.Text)

    def to_dict(self):
        return {
            "id": self.id,
            "nome": self.nome,
            "email": self.email,
            "telefone": self.telefone,
            "linkedin": self.linkedin,
            "observacoes": self.observacoes
        }

class Vaga(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    nome = db.Column(db.String(100), nullable=False)

    def to_dict(self):
        return {"id": self.id, "nome": self.nome}

class ProcessoRecrutamento(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    candidato_id = db.Column(db.Integer, db.ForeignKey('candidato.id'))
    vaga_id = db.Column(db.Integer, db.ForeignKey('vaga.id'))
    status = db.Column(db.String(50), default="agendado_comigo")
    data_entrevista = db.Column(db.DateTime)
    observacoes = db.Column(db.Text)
    feedback = db.Column(db.Text)
    data_atualizacao = db.Column(db.DateTime, default=datetime.utcnow)

    candidato = db.relationship('Candidato')
    vaga = db.relationship('Vaga')

    def to_dict(self):
        return {
            "id": self.id,
            "candidato_id": self.candidato_id,
            "vaga_id": self.vaga_id,
            "status": self.status,
            "data_entrevista": self.data_entrevista.isoformat() if self.data_entrevista else None,
            "observacoes": self.observacoes,
            "feedback": self.feedback,
            "candidato_nome": self.candidato.nome if self.candidato else None,
            "vaga_nome": self.vaga.nome if self.vaga else None
        }

class Lembrete(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    processo_id = db.Column(db.Integer, db.ForeignKey('processo_recrutamento.id'))
    titulo = db.Column(db.String(100))
    descricao = db.Column(db.Text)
    data_lembrete = db.Column(db.DateTime)
    concluido = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    processo = db.relationship('ProcessoRecrutamento')

    def to_dict(self):
        return {
            "id": self.id,
            "processo_id": self.processo_id,
            "titulo": self.titulo,
            "descricao": self.descricao,
            "data_lembrete": self.data_lembrete.isoformat() if self.data_lembrete else None,
            "concluido": self.concluido,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "candidato_nome": self.processo.candidato.nome if self.processo and self.processo.candidato else None,
            "vaga_nome": self.processo.vaga.nome if self.processo and self.processo.vaga else None
        }
