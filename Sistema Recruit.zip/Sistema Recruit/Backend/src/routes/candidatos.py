from flask import Blueprint, request, jsonify
from src.models.user import db
from src.models.recruitment import Candidato

candidatos_bp = Blueprint('candidatos', __name__)

@candidatos_bp.route('/candidatos', methods=['GET'])
def listar_candidatos():
    try:
        candidatos = Candidato.query.order_by(Candidato.nome.asc()).all()
        return jsonify([c.to_dict() for c in candidatos])
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@candidatos_bp.route('/candidatos/<int:candidato_id>', methods=['GET'])
def obter_candidato(candidato_id):
    try:
        candidato = Candidato.query.get_or_404(candidato_id)
        return jsonify(candidato.to_dict())
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@candidatos_bp.route('/candidatos', methods=['POST'])
def criar_candidato():
    try:
        data = request.get_json()
        if not data.get('nome') or not data.get('email'):
            return jsonify({'error': 'Nome e email são obrigatórios'}), 400
        novo = Candidato(
            nome=data['nome'],
            email=data['email'],
            telefone=data.get('telefone'),
            linkedin=data.get('linkedin'),
            observacoes=data.get('observacoes')
        )
        db.session.add(novo)
        db.session.commit()
        return jsonify(novo.to_dict()), 201
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@candidatos_bp.route('/candidatos/<int:candidato_id>', methods=['PUT'])
def atualizar_candidato(candidato_id):
    try:
        candidato = Candidato.query.get_or_404(candidato_id)
        data = request.get_json()
        candidato.nome = data.get('nome', candidato.nome)
        candidato.email = data.get('email', candidato.email)
        candidato.telefone = data.get('telefone', candidato.telefone)
        candidato.linkedin = data.get('linkedin', candidato.linkedin)
        candidato.observacoes = data.get('observacoes', candidato.observacoes)
        db.session.commit()
        return jsonify(candidato.to_dict())
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@candidatos_bp.route('/candidatos/<int:candidato_id>', methods=['DELETE'])
def deletar_candidato(candidato_id):
    try:
        candidato = Candidato.query.get_or_404(candidato_id)
        db.session.delete(candidato)
        db.session.commit()
        return jsonify({'message': 'Candidato deletado com sucesso'}), 200
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500
