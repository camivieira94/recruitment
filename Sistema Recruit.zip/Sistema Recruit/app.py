from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from flask_cors import CORS

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///db.sqlite3'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db = SQLAlchemy(app)
CORS(app)

from src.routes.candidatos import candidatos_bp
from src.routes.processos import processos_bp
from src.routes.lembretes import lembretes_bp

app.register_blueprint(candidatos_bp)
app.register_blueprint(processos_bp)
app.register_blueprint(lembretes_bp)

with app.app_context():
    db.create_all()

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)
